import pickle
import argparse
import argcomplete
from argcomplete.completers import ChoicesCompleter
from argcomplete.completers import EnvironCompleter
import requests
from bs4 import BeautifulSoup


def get_main_page():
    '''
    Make request to booking page and parse html
    :param offset:
    :return: html page
    '''
    
    url = 'https://www.booking.com/searchresults.it.html?label=gen173nr-1DCAEoggI46AdIM1gEaHGIAQGYARS4ARfIAQzYAQPoAQGIAgGoAgO4AvG0zu8FwAIB&sid=9267fc72e7a76cccd2705d69ebe88424&sb=1&src=index&src_elem=sb&error_url=https%3A%2F%2Fwww.booking.com%2Findex.it.html%3Flabel%3Dgen173nr-1DCAEoggI46AdIM1gEaHGIAQGYARS4ARfIAQzYAQPoAQGIAgGoAgO4AvG0zu8FwAIB%3Bsid%3D9267fc72e7a76cccd2705d69ebe88424%3Bsb_price_type%3Dtotal%26%3B&ss=Italia&is_ski_area=0&checkin_year=2019&checkin_month=12&checkin_monthday=13&checkout_year=2019&checkout_month=12&checkout_monthday=14&group_adults=2&group_children=0&no_rooms=1&b_h4u_keep_filters=&from_sf=1&ss_raw=ital&ac_position=0&ac_langcode=it&ac_click_type=b&dest_id=104&dest_type=country&place_id_lat=43.2946&place_id_lon=12.0333&search_pageview_id=221f62f8736d0073&search_selected=true'
    r = requests.get(url, timeout=5)
    html = r.content
    parsed_html = BeautifulSoup(html, "html.parser")
    return parsed_html

def get_pages() :

    links=[]
    base_url="https://www.booking.com/searchresults.it.html?aid=304142&label=gen173nr-1DCAEoggI46AdIM1gEaHGIAQGYARS4ARfIAQzYAQPoAQGIAgGoAgO4AvG0zu8FwAIB&tmpl=searchresults&ac_click_type=b&ac_position=0&checkin_month=12&checkin_monthday=13&checkin_year=2019&checkout_month=12&checkout_monthday=14&checkout_year=2019&class_interval=1&dest_id=104&dest_type=country&from_sf=1&group_adults=2&group_children=0&label_click=undef&no_rooms=1&raw_dest_type=country&room1=A%2CA&sb_price_type=total&search_selected=1&shw_aparth=1&slp_r_match=0&src=index&src_elem=sb&srpvid=34586cac25f10065&ss=Italia&ss_raw=ital&ssb=empty&top_ufis=1&rows=25&offset="
    startoffset=25
    while startoffset<=375 :
        offsetStr=str(startoffset)
        url=base_url+offsetStr
        links.append(url)
        startoffset+=25
    return links
    
def get_hotels(url) :

    r=requests.get(url,timeout=50)
    html=r.content
    parsed_html=BeautifulSoup(html,"html.parser")
    return parsed_html
    hotel_links=[]
    hotels_links=parsed_html.findAll('a',{'class':"hotel_name_link url"})
    links=[]
    for hotel_link in hotel_links:
        links.append(hotel_link['href'])
    return links
    

def get_data(url) :

##  url='https://www.booking.com/hotel/it/pinzolo-dolomiti.it.html?label=gen173nr-1DCAEoggI46AdIM1gEaHGIAQGYARS4ARfIAQzYAQPoAQGIAgGoAgO4AvG0zu8FwAIB;sid=9267fc72e7a76cccd2705d69ebe88424;all_sr_blocks=8923901_88440845_0_0_0;checkin=2019-12-13;checkout=2019-12-14;dest_id=104;dest_type=country;dist=0;group_adults=2;group_children=0;hapos=26;highlighted_blocks=8923901_88440845_0_0_0;hpos=26;no_rooms=1;room1=A%2CA;sb_price_type=total;sr_order=popularity;srepoch=1576249150;srpvid=1184695eb95800bd;type=total;ucfs=1&#hotelTmpl'
    r = requests.get(url, timeout=5)
    html = r.content
    parsed_html = BeautifulSoup(html, "html.parser")
    data=[]
    hotel_name=parsed_html.find('div',{'class':"hp__hotel-title"})
    data.append(hotel_name.find('h2').text)
    numberReview=parsed_html.find('div',{'class':"bui-review-score__text"})
    data.append(numberReview.text)
    averageReview=parsed_html.find('div',{'class':"bui-review-score__badge"})
    data.append(averageReview.text)
    address=parsed_html.find('span',{'class':"hp_address_subtitle js-hp_address_subtitle jq_tooltip"})
    data.append(address.text)
    blueBars=parsed_html.findAll('li',{'class':"v2_review-scores__subscore"})
    for bluebar in blueBars:
        type=bluebar.find('span',{'class':"c-score-bar__title"})
        if(type.text=="Rapporto qualità-prezzo" or type.text=="Staff" or type.text=="Servizi"):
            value=bluebar.find('span',{'class':"c-score-bar__score"})
            data.append(value.text)
    print(data)
    

def main() :

    pages=get_pages()
    
    data=get_hotels("https://www.booking.com/searchresults.it.html?aid=304142&label=gen173nr-1DCAEoggI46AdIM1gEaHGIAQGYARS4ARfIAQzYAQPoAQGIAgGoAgO4AvG0zu8FwAIB&tmpl=searchresults&ac_click_type=b&ac_position=0&checkin_month=12&checkin_monthday=13&checkin_year=2019&checkout_month=12&checkout_monthday=14&checkout_year=2019&class_interval=1&dest_id=104&dest_type=country&dtdisc=0&from_sf=1&group_adults=2&group_children=0&inac=0&index_postcard=0&label_click=undef&no_rooms=1&postcard=0&raw_dest_type=country&room1=A%2CA&sb_price_type=total&search_selected=1&shw_aparth=1&slp_r_match=0&src=index&src_elem=sb&srpvid=241c71627b620079&ss=Italia&ss_all=0&ss_raw=ital&ssb=empty&sshis=0&top_ufis=1&rows=25")
    print(data)
    
    
if __name__ == "__main__":
    main()
